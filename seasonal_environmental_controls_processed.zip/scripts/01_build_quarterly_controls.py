#!/usr/bin/env python3
"""Build the city-quarter environmental controls used in the published analysis."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


PACKAGE_DIR = Path(__file__).resolve().parents[1]
RAW_DIR = PACKAGE_DIR / "raw"
PROCESSED_DIR = PACKAGE_DIR / "processed"
VALIDATION_DIR = PACKAGE_DIR / "validation"
YEARS = range(2013, 2021)
KEYS = ["city_code", "year", "quarter"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reference-main",
        type=Path,
        help="Optional path to the paper's main.dta for value-by-value validation.",
    )
    return parser.parse_args()


def require_columns(frame: pd.DataFrame, columns: list[str], source: str) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"{source} is missing required columns: {missing}")


def numeric(series: pd.Series, name: str) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce")
    if values.isna().any() and series.notna().any():
        bad = series[values.isna() & series.notna()].astype(str).head(5).tolist()
        if bad:
            raise ValueError(f"Could not parse {name}; examples: {bad}")
    return values


def validate_keys(frame: pd.DataFrame, name: str) -> None:
    if frame[KEYS].isna().any().any():
        raise ValueError(f"{name} contains missing key values")
    invalid_quarters = sorted(set(frame["quarter"]) - {1, 2, 3, 4})
    if invalid_quarters:
        raise ValueError(f"{name} contains invalid quarters: {invalid_quarters}")
    duplicates = frame.duplicated(KEYS, keep=False)
    if duplicates.any():
        example = frame.loc[duplicates, KEYS].head(5).to_dict("records")
        raise ValueError(f"{name} contains duplicate keys; examples: {example}")


def read_temperature() -> pd.DataFrame:
    frames = []
    source_dir = RAW_DIR / "temperature"
    for year in YEARS:
        path = source_dir / f"temperature_monthly_{year}.csv"
        frame = pd.read_csv(path, encoding="gb18030")
        require_columns(frame, ["年月", "城市代码", "平均气温"], path.name)
        frames.append(frame[["年月", "城市代码", "平均气温"]])

    monthly = pd.concat(frames, ignore_index=True)
    year_month = numeric(monthly["年月"], "temperature year-month").astype("int64")
    monthly = pd.DataFrame(
        {
            "city_code": numeric(monthly["城市代码"], "temperature city code").astype("int64"),
            "year": year_month // 100,
            "month": year_month % 100,
            "temperature_c": numeric(monthly["平均气温"], "average temperature"),
        }
    )
    monthly["quarter"] = ((monthly["month"] - 1) // 3 + 1).astype("int64")
    quarterly = (
        monthly.groupby(KEYS, as_index=False, sort=True)
        .agg(
            temperature_c=("temperature_c", "mean"),
            temperature_months_observed=("temperature_c", "count"),
        )
        .sort_values(KEYS)
        .reset_index(drop=True)
    )
    validate_keys(quarterly, "temperature")
    return quarterly


def read_precipitation() -> pd.DataFrame:
    path = RAW_DIR / "precipitation" / "precipitation_daily_2000_2020.csv.gz"
    daily = pd.read_csv(path, encoding="utf-8-sig", compression="gzip")
    require_columns(daily, ["日期", "市代码", "降水量"], path.name)
    dates = pd.to_datetime(daily["日期"], errors="raise")
    daily = pd.DataFrame(
        {
            "city_code": numeric(daily["市代码"], "precipitation city code").astype("int64"),
            "year": dates.dt.year.astype("int64"),
            "month": dates.dt.month.astype("int64"),
            "precipitation": numeric(daily["降水量"], "daily precipitation"),
        }
    )
    daily = daily[daily["year"].between(min(YEARS), max(YEARS))].copy()
    monthly = (
        daily.groupby(["city_code", "year", "month"], as_index=False, sort=True)
        .agg(
            monthly_daily_mean=("precipitation", "mean"),
            monthly_total=("precipitation", "sum"),
            days_observed=("precipitation", "count"),
        )
    )
    monthly["quarter"] = ((monthly["month"] - 1) // 3 + 1).astype("int64")
    quarterly = (
        monthly.groupby(KEYS, as_index=False, sort=True)
        .agg(
            precipitation_daily_mean=("monthly_daily_mean", "mean"),
            precipitation_quarter_total=("monthly_total", "sum"),
            precipitation_days_observed=("days_observed", "sum"),
            precipitation_months_observed=("monthly_daily_mean", "count"),
        )
        .sort_values(KEYS)
        .reset_index(drop=True)
    )
    validate_keys(quarterly, "precipitation")
    return quarterly


def read_sunshine() -> pd.DataFrame:
    path = RAW_DIR / "sunshine" / "sunshine_city_quarter_1960_2020.csv"
    frame = pd.read_csv(path, encoding="utf-8-sig")
    require_columns(frame, ["行政区划代码", "年份", "quarter", "日照时数"], path.name)
    quarterly = pd.DataFrame(
        {
            "city_code": numeric(frame["行政区划代码"], "sunshine city code").astype("int64"),
            "year": numeric(frame["年份"], "sunshine year").astype("int64"),
            "quarter": numeric(frame["quarter"], "sunshine quarter").astype("int64"),
            "sunshine_hours": numeric(frame["日照时数"], "sunshine duration"),
        }
    )
    quarterly = quarterly[quarterly["year"].between(min(YEARS), max(YEARS))]
    quarterly = quarterly.sort_values(KEYS).reset_index(drop=True)
    validate_keys(quarterly, "sunshine")
    return quarterly


def read_air_quality() -> pd.DataFrame:
    path = RAW_DIR / "air_quality" / "air_quality_monthly_2013_2024.xlsx"
    frame = pd.read_excel(path, sheet_name="sheet1 (2)", dtype={"城市代码": "string"})
    require_columns(frame, ["统计月度", "城市代码", "AQI"], path.name)
    year_month = numeric(frame["统计月度"], "AQI year-month").astype("Int64")
    monthly = pd.DataFrame(
        {
            "city_code": numeric(frame["城市代码"], "AQI city code").astype("Int64"),
            "year": year_month // 100,
            "month": year_month % 100,
            "aqi": numeric(frame["AQI"], "AQI"),
        }
    ).dropna(subset=["city_code", "year", "month"])
    monthly = monthly[monthly["year"].between(min(YEARS), max(YEARS))].copy()
    monthly[["city_code", "year", "month"]] = monthly[["city_code", "year", "month"]].astype("int64")
    monthly["quarter"] = ((monthly["month"] - 1) // 3 + 1).astype("int64")
    quarterly = (
        monthly.groupby(KEYS, as_index=False, sort=True)
        .agg(aqi=("aqi", "mean"), aqi_months_observed=("aqi", "count"))
        .sort_values(KEYS)
        .reset_index(drop=True)
    )
    validate_keys(quarterly, "air quality")
    return quarterly


def write_dataset(frame: pd.DataFrame, stem: str) -> None:
    csv_path = PROCESSED_DIR / f"{stem}.csv"
    dta_path = PROCESSED_DIR / f"{stem}.dta"
    frame.to_csv(csv_path, index=False, encoding="utf-8", float_format="%.10g")
    stata_frame = frame.copy()
    count_columns = [column for column in stata_frame if column.endswith("_observed")]
    for column in count_columns:
        stata_frame[column] = stata_frame[column].astype("int32")
    labels = {
        "city_code": "Six-digit prefecture-level administrative code",
        "year": "Calendar year",
        "quarter": "Calendar quarter (1-4)",
        "aqi": "Mean monthly Air Quality Index within city-quarter",
        "temperature_c": "Mean monthly average temperature within city-quarter (C)",
        "temperature_months_observed": "Monthly temperature observations used",
        "precipitation_daily_mean": "Mean of monthly mean-daily precipitation values",
        "precipitation_quarter_total": "Sum of daily precipitation within city-quarter",
        "precipitation_days_observed": "Daily precipitation observations used",
        "precipitation_months_observed": "Monthly precipitation groups used",
        "sunshine_hours": "Sunshine duration within city-quarter (hours)",
        "aqi_months_observed": "Nonmissing monthly AQI observations used",
    }
    stata_frame.to_stata(
        dta_path,
        write_index=False,
        version=118,
        variable_labels={column: labels[column] for column in stata_frame if column in labels},
    )


def file_manifest() -> list[dict[str, object]]:
    records = []
    for path in sorted(RAW_DIR.rglob("*")):
        if not path.is_file():
            continue
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        record = {
            "path": path.relative_to(PACKAGE_DIR).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": digest.hexdigest(),
        }
        if path.suffix == ".gz":
            import gzip

            uncompressed_digest = hashlib.sha256()
            uncompressed_bytes = 0
            with gzip.open(path, "rb") as handle:
                for block in iter(lambda: handle.read(1024 * 1024), b""):
                    uncompressed_digest.update(block)
                    uncompressed_bytes += len(block)
            record["uncompressed_bytes"] = uncompressed_bytes
            record["uncompressed_sha256"] = uncompressed_digest.hexdigest()
        records.append(record)
    return records


def compare_to_reference(combined: pd.DataFrame, reference_path: Path) -> dict[str, object]:
    expected_columns = ["citycode", "year", "quarter", "aqi", "Temperature", "Precipitation", "Sunshine"]
    reference = pd.read_stata(reference_path, convert_categoricals=False, columns=expected_columns)
    reference = reference.rename(
        columns={
            "citycode": "city_code",
            "Temperature": "temperature_c",
            "Precipitation": "precipitation_daily_mean",
            "Sunshine": "sunshine_hours",
        }
    )
    reference[KEYS] = reference[KEYS].astype("int64")
    merged = reference.merge(combined, on=KEYS, how="left", suffixes=("_reference", "_built"), validate="many_to_one")
    variables = ["aqi", "temperature_c", "precipitation_daily_mean", "sunshine_hours"]
    tolerances = {
        "aqi": 1e-8,
        "temperature_c": 1e-5,
        "precipitation_daily_mean": 1e-7,
        # The retained sunshine CSV is rounded to three decimal places.
        "sunshine_hours": 5.1e-4,
    }
    results = {}
    any_failure = False
    for variable in variables:
        tolerance = tolerances[variable]
        left = merged[f"{variable}_reference"]
        right = merged[f"{variable}_built"]
        comparable = left.notna() & right.notna()
        diffs = (left[comparable] - right[comparable]).abs()
        mismatches = int((diffs > tolerance).sum())
        missing_built = int((left.notna() & right.isna()).sum())
        results[variable] = {
            "reference_nonmissing": int(left.notna().sum()),
            "built_nonmissing_for_reference_keys": int(right.notna().sum()),
            "comparable_values": int(comparable.sum()),
            "missing_built_when_reference_nonmissing": missing_built,
            "mismatches_above_tolerance": mismatches,
            "maximum_absolute_difference": None if diffs.empty else float(diffs.max()),
            "tolerance": tolerance,
        }
        any_failure |= mismatches > 0 or missing_built > 0
    results["passed"] = not any_failure
    return results


def main() -> None:
    args = parse_args()
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    VALIDATION_DIR.mkdir(parents=True, exist_ok=True)

    temperature = read_temperature()
    precipitation = read_precipitation()
    sunshine = read_sunshine()
    air_quality = read_air_quality()

    write_dataset(temperature, "temperature_quarterly_2013_2020")
    write_dataset(precipitation, "precipitation_quarterly_2013_2020")
    write_dataset(sunshine, "sunshine_quarterly_2013_2020")
    write_dataset(air_quality, "air_quality_quarterly_2013_2020")

    combined = temperature[KEYS + ["temperature_c"]]
    combined = combined.merge(
        precipitation[KEYS + ["precipitation_daily_mean", "precipitation_quarter_total"]],
        on=KEYS,
        how="outer",
        validate="one_to_one",
    )
    combined = combined.merge(sunshine, on=KEYS, how="outer", validate="one_to_one")
    combined = combined.merge(air_quality[KEYS + ["aqi"]], on=KEYS, how="outer", validate="one_to_one")
    combined = combined[
        KEYS
        + [
            "aqi",
            "temperature_c",
            "precipitation_daily_mean",
            "precipitation_quarter_total",
            "sunshine_hours",
        ]
    ].sort_values(KEYS).reset_index(drop=True)
    validate_keys(combined, "combined environmental controls")
    write_dataset(combined, "environmental_controls_quarterly_2013_2020")

    report: dict[str, object] = {
        "sample_period": [min(YEARS), max(YEARS)],
        "row_counts": {
            "temperature": len(temperature),
            "precipitation": len(precipitation),
            "sunshine": len(sunshine),
            "air_quality": len(air_quality),
            "combined_outer_join": len(combined),
        },
        "combined_nonmissing": {
            column: int(combined[column].notna().sum())
            for column in ["aqi", "temperature_c", "precipitation_daily_mean", "sunshine_hours"]
        },
        "raw_file_manifest": file_manifest(),
    }
    if args.reference_main:
        report["reference_validation"] = compare_to_reference(combined, args.reference_main.resolve())

    report_path = VALIDATION_DIR / "validation_report.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if args.reference_main and not report["reference_validation"]["passed"]:
        raise SystemExit("Reference validation failed. See validation/validation_report.json.")


if __name__ == "__main__":
    main()
